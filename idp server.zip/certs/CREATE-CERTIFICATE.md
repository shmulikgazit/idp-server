# Certificate Generation for SAML Signing

## Overview
This document explains how to generate a proper X.509 certificate for SAML assertion signing when you have an existing private key.

## Problem
The SAML signature validation was failing with error:
```
exception_class: org.opensaml.xml.validation.ValidationException
exception_message: Signature did not validate against the credential's key
```

**Root Cause:** Mismatch between the certificate included in SAML response and the private key used for signing.

## Solution: Generate Matching Certificate

### Prerequisites
- OpenSSL installed and accessible
- Existing private key file: `signing-private.pem`
- OpenSSL configuration file (e.g., `c:\openssl\bin\openssl.cfg`)

### Step-by-Step Process

#### 1. Navigate to certs directory
```bash
cd certs
```

#### 2. Generate Certificate Signing Request (CSR)
```bash
openssl req -new -sha256 -key signing-private.pem -out csr.pem -config c:\openssl\bin\openssl.cfg
```

**Certificate Information to Enter:**
- Country Name (2 letter code): `AU`
- State or Province Name: `Some-State`
- Locality Name (city): `City`
- Organization Name: `Internet Widgits Pty Ltd`
- Organizational Unit Name: `NA`
- **Common Name (FQDN)**: `sso.signing.com` ← **Important for SAML**
- Email Address: `shmulikg@liveperson.com`
- Challenge password: `1234`
- Optional company name: *(leave blank)*

#### 3. Backup existing certificate (if any)
```bash
ren signing-cert.pem oldcert.pem
```

#### 4. Generate self-signed certificate
```bash
openssl x509 -req -in csr.pem -signkey signing-private.pem -out cert.pem -days 720
```

**Output should show:**
```
Signature ok
subject=C = AU, ST = Some-State, L = City, O = Internet Widgits Pty Ltd, OU = NA, CN = sso.signing.com, emailAddress = shmulikg@liveperson.com
Getting Private key
```

#### 5. Rename to expected filename
```bash
ren cert.pem signing-cert.pem
```

#### 6. Clean up temporary files
```bash
del csr.pem
del oldcert.pem
```

## LivePerson Encryption Certificate

### Automatic Format Handling
The system now automatically handles certificate format conversion:
- **Just use PEM files** - Place `lpsso202X.pem` files in the certs directory
- **Automatic conversion** - System converts PEM to DER format when needed for samlify compatibility
- **No manual conversion required** - No more OpenSSL commands or DER file management
- **Console logging** - Shows conversion progress for transparency
- **Graceful error handling** - Clear error messages if conversion fails

### Example Console Output
When the system auto-converts a certificate, you'll see:
```
🔄 DER requested but only PEM available, auto-converting: lpsso2026
📁 Converting PEM file: C:\path\to\certs\lpsso2026.pem
✅ AUTO-CONVERTED PEM to DER: lpsso2026
🔍 Original PEM size: 1150 characters
🔍 Converted DER size: 793 bytes
💡 No manual conversion needed - PEM files work automatically!
```

### Dynamic Certificate Selection
The Denver SSO page now supports selecting different encryption certificates:
- **Default:** lpsso2026 (current year)
- **Configurable:** lpsso2027, lpsso2028 (future years)
- **UI Control:** Dropdown selector appears when encryption is enabled
- **Runtime Selection:** No code changes needed to test different certificates

### Final Certificate Files

After successful generation, you should have:

| File | Description | Status |
|------|-------------|---------|
| `signing-private.pem` | RSA private key | ✅ Existing |
| `signing-cert.pem` | Self-signed X.509 certificate | ✅ Generated |
| `signing-public.pem` | RSA public key | ✅ Existing |
| `lpsso202X.pem` | LivePerson encryption certificates | ✅ Place in certs/ directory |

### Certificate Properties

- **Validity Period:** 720 days (2 years)
- **Hash Algorithm:** SHA-256
- **Certificate Type:** Self-signed X.509
- **Key Pair Match:** ✅ Verified working
- **SAML Compatibility:** ✅ Validated

### Verification

After certificate generation, verify SAML functionality:

1. **Server Health Check:**
   ```bash
   curl http://localhost:3000/health
   ```
   Should show: `"saml":{"initialized":true}`

2. **SAML Generation Test:**
   - Navigate to `/agentsso-denver`
   - Click "Generate SAML Assertion"
   - Should generate without errors

3. **Login Test:**
   - Use Site ID: `50922448`
   - Use Username: `supportteam`
   - Click "🚀 Login with Denver SSO"
   - Should successfully authenticate

### For LivePerson Configuration

If LivePerson needs your certificate for SAML validation:

1. **Extract certificate content:**
   ```bash
   type signing-cert.pem
   ```

2. **Provide the certificate** (without private key) to LivePerson support for their SAML configuration.

### Troubleshooting

**If SAML still shows "initialized": false:**
- Check server console logs for certificate loading errors
- Verify certificate file format (should start with `-----BEGIN CERTIFICATE-----`)
- Ensure private key file is accessible and properly formatted

**If signature validation still fails:**
- Verify certificate and private key are a matching pair
- Check that the certificate in SAML response matches your generated certificate
- Validate certificate using online tools (e.g., https://www.samltool.com/validate_response.php)

**If encryption fails:**
- Ensure PEM certificate files exist: `lpsso202X.pem`
- Check server logs for auto-conversion progress and any errors
- Verify PEM files contain valid certificate data (start with `-----BEGIN CERTIFICATE-----`)
- Ensure certificate files have proper permissions

### Generated On
Date: June 26, 2025  
Success: ✅ SAML login working with Site ID 50922448 and username supportteam  
Tested: Denver SSO authentication successful 